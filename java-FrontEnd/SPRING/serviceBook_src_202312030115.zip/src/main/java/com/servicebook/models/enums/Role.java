
package com.servicebook.models.enums;

/**
 *
 * @author lion
 */
public enum Role {
	USER,
	ADMIN,
	PROVEEDOR        
}
