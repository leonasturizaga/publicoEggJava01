package com.servicebook.models.enums;

public enum Estrellas {

    UNA_ESTRELLA(1),
    DOS_ESTRELLAS(2),
    TRES_ESTRELLAS(3),
    CUATRO_ESTRELLAS(4),
    CINCO_ESTRELLAS(5);

    Estrellas(double i) {

    }
}
