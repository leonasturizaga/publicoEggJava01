package com.servicebook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
