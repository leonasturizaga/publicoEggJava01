
package Entidades;


public class DivisionNumero {
//3. Defina una clase llamada DivisionNumero. En el método main utilice un Scanner para leer dos
//números en forma de cadena. A continuación, utilice el método parseInt() de la clase Integer,
//para convertir las cadenas al tipo int y guardarlas en dos variables de tipo int. Por ultimo realizar
//una división con los dos numeros y mostrar el resultado.

public int convertirCadena(String var){
	int a = Integer.parseInt(var);
	return a;
}



}
