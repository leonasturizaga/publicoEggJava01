
package Entidades;

import java.util.HashSet;


public class Pais {
//5. Se requiere un programa que lea y guarde países, y para evitar que se ingresen repetidos usaremos un conjunto.
HashSet<String> pais = new HashSet();

	public Pais() {
	}

	public HashSet<String> getPais() {
		return pais;
	}



}
