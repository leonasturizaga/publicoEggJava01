
package Entidades;

import java.util.ArrayList;
import java.util.Scanner;


public class Video {

private Scanner leer = new Scanner(System.in);
private ArrayList<String> mascota;

	public Video(ArrayList<String> mascota) {
		this.mascota = mascota;
	}



}
