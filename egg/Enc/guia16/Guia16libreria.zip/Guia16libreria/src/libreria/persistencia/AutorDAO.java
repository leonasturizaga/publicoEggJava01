
package libreria.persistencia;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import libreria.entidades.Autor;


public class AutorDAO {

    private final EntityManagerFactory emf = Persistence.createEntityManagerFactory("Guia16libreriaPU");
    private EntityManager em = emf.createEntityManager();

//conectar a base de datos	 
    public void conectar() {
        if (!em.isOpen()) {
            em = emf.createEntityManager();
        }
    }		
//desconectar de base de datos
    public void desconectar() {
        if (em.isOpen()) {
            em.close();
        }
    }

//buscar Autor por id
    public Autor buscarPorId(int id) throws Exception {
        conectar();
        Autor autor = em.find(Autor.class, id);
        desconectar();
        return autor;
    }	 


	 
}
