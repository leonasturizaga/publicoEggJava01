
package libreria.persistencia;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import libreria.entidades.Libro;



public class LibroDAO {

    private final EntityManagerFactory emf = Persistence.createEntityManagerFactory("Guia16libreriaPU");
    private EntityManager em = emf.createEntityManager();

//conectar a base de datos	 
    public void conectar() {
        if (!em.isOpen()) {
            em = emf.createEntityManager();
        }
    }		
//desconectar de base de datos
    public void desconectar() {
        if (em.isOpen()) {
            em.close();
        }
    }

//buscar Libro por id
    public Libro buscarPorId(int id) throws Exception {
        conectar();
        Libro libro = em.find(Libro.class, id);
        desconectar();
        return libro;
    }	 	
}
