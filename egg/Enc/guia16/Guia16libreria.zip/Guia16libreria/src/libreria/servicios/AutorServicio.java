
package libreria.servicios;

import libreria.entidades.Autor;


public class AutorServicio {



}
