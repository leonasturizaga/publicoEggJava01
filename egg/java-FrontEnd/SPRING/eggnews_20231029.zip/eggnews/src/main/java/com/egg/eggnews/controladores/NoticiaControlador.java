
package com.egg.eggnews.controladores;

import com.egg.eggnews.entidades.Noticia;
import com.egg.eggnews.excepciones.MiException;
import com.egg.eggnews.servicios.NoticiaServicio;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/")
public class NoticiaControlador {

@Autowired
private NoticiaServicio noticiaServicio;

@GetMapping("/inicio")
public String inicio(ModelMap modelo){
	List<Noticia> noticias = noticiaServicio.listarNoticias();
	modelo.addAttribute("noticias", noticias);
	return "inicio.html";
}


@GetMapping("/noticia/registrar")
public String registrar(){
	return "noticia_form.html";
}

@PostMapping("/noticia/registro")
public String registro(@RequestParam String titulo, @RequestParam String cuerpo, ModelMap modelo){
	try {
		noticiaServicio.creacion(titulo, cuerpo);
		System.out.println("titulo:" + titulo + " cuerpo: " + cuerpo);
		modelo.put("exito", "Noticia creada correctamente");
			return "noticia_form.html";
	} catch (MiException ex) {
		Logger.getLogger(NoticiaControlador.class.getName()).log(Level.SEVERE, null, ex);
		modelo.put("error", ex.getMessage());
		return "noticia_form.html";
	}
}

@GetMapping("/noticia/modificar/{id}")
public String modificar(@PathVariable String id, ModelMap modelo){
	System.out.println("@GetMapping(\"/noticia/modificar/{id}\")");
	modelo.put("noticia", noticiaServicio.getOne(id));
	System.out.println("id: " + id + "noticia: " );
	return "noticia_modificar.html";
}

@PostMapping("/noticia/modificar/{id}")
public String modificar(@PathVariable String id, @RequestParam String titulo, @RequestParam String cuerpo, ModelMap modelo){
	try {
		noticiaServicio.modificacion(id, titulo, cuerpo);
		System.out.println("id: " + id +"  titulo:" + titulo + " cuerpo: " + cuerpo);
		modelo.put("exito", "Noticia modificada correctamente");
			return "redirect:../../inicio";
	} catch (MiException ex) {
		Logger.getLogger(NoticiaControlador.class.getName()).log(Level.SEVERE, null, ex);
		modelo.put("error", ex.getMessage());
		return "noticia_modificar.html";
	}
}

@GetMapping("/panel")
public String panel(){
	return "panelAdmin.html";
}

@PostMapping("/panelAdmin")
public String panelAdmin(){

	return "panelAdmin.html";
}

}
