
package com.egg.biblioteca.controladores;

import com.egg.biblioteca.entidades.Usuario;
import com.egg.biblioteca.servicios.UsuarioServicio;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
public class AdminControlador {
	
	@Autowired
	private UsuarioServicio usuarioServicio;
	
	@GetMapping("dashboard")
	public String panelAdministrativo(){
		return "panel.html";
	}
	
	@GetMapping("/usuarios")
	public String listar(ModelMap modelo){
		List<Usuario> usuarios = usuarioServicio.listarUsuarios();
		modelo.addAttribute("usuarios", usuarios);
		
		return "usuario_list.html";
	}
	
	@GetMapping("/modificarRol/{id}")
	public String cambiarRol(@PathVariable String id){
		usuarioServicio.cambiarRol(id);
		System.out.println("mod rol:" + usuarioServicio.getOne(id).getRol().toString());
		return "redirect:/admin/usuarios";
	}
	
	//metodo auxiliar para modificar desde lista de usuarios
	@GetMapping("/perfil/{id}")
	public String perfilMod(@PathVariable String id,  ModelMap modelo){
		Usuario usuario = usuarioServicio.getOne(id);
			modelo.put("id", id);
			modelo.put("nombre", usuario.getNombre());
			modelo.put("email", usuario.getEmail());
			modelo.put("imagen", usuario.getImagen());
		
		
		return "redirect:/perfil/{id}";
	}	
	
}
