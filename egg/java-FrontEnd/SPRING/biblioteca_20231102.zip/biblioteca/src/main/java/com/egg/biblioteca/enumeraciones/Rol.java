
package com.egg.biblioteca.enumeraciones;


public enum Rol {
	USER,
	ADMIN;
}
