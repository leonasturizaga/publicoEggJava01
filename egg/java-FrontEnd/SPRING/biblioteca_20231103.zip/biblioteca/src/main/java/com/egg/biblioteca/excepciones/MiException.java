
package com.egg.biblioteca.excepciones;


public class MiException extends Exception{

//agregamos constructor y recibe el mensaje
	public MiException(String msg) {
		super(msg);
	}


}
