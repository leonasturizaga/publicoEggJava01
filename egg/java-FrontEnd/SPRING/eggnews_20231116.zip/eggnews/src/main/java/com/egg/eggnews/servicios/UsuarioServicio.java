
package com.egg.eggnews.servicios;

import com.egg.eggnews.entidades.Imagen;
import com.egg.eggnews.entidades.Noticia;
import com.egg.eggnews.entidades.Periodista;
import com.egg.eggnews.entidades.Usuario;
import com.egg.eggnews.enumeraciones.Rol;
import com.egg.eggnews.excepciones.MiException;
import com.egg.eggnews.repositorios.PeriodistaRepositorio;
import com.egg.eggnews.repositorios.UsuarioRepositorio;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

@Service
public class UsuarioServicio implements UserDetailsService{
	@Autowired
	private UsuarioRepositorio usuarioRepositorio;
	@Autowired
	private PeriodistaServicio periodistaServicio;
	@Autowired 
	private PeriodistaRepositorio periodistaRepositorio;
	@Autowired
	private ImagenServicio imagenServicio;
	
	@Transactional
public void registrarUsuario(MultipartFile archivo, String nombreUsuario, Rol rol, String password, String password2) throws MiException{
		System.out.println("validar: " + nombreUsuario + " " + rol + " " + password + " " + password2 );
	validar(nombreUsuario, rol, password, password2);

	Periodista periodista = new Periodista();
	Usuario usuario = new Usuario();
	usuario.setNombreUsuario(nombreUsuario);
	if(rol.equals(rol.USER)){
		usuario.setRol(Rol.USER);
	}
	if (rol.equals(rol.ADMIN)) {
		usuario.setRol(Rol.ADMIN);
	}
	if (rol.equals(rol.PERIODISTA)) {
		usuario.setRol(Rol.PERIODISTA);
	}

	Imagen imagen = imagenServicio.guardar(archivo);
	usuario.setImagen(imagen);
	
	//	usuario.setPassword(password);
	usuario.setPassword(new BCryptPasswordEncoder().encode(password));
	Date fechaAlta = new Date();
	usuario.setFechaAlta(fechaAlta);
	usuario.setActivo(Boolean.TRUE);

	usuarioRepositorio.save(usuario);
		System.out.println("usuario0: " + usuario.toString());
		if (usuario.getRol().equals(Rol.PERIODISTA)) {
			String idPeriodista = usuario.getId();

			periodistaServicio.registrarPeriodista(idPeriodista);

			System.out.println("usuario1: " + usuario.toString());
			Optional<Periodista> respuesta = periodistaRepositorio.findById(usuario.getId());
			if (respuesta.isPresent()) {
				periodista = respuesta.get();
				usuario.setPeriodista(periodista);
			}

			usuarioRepositorio.save(usuario);
			System.out.println("usuario2: " + usuario.toString());
		}

}

public void modificarUsuario(MultipartFile archivoNew, String id, String nombreUsuario, Rol rol, String password, String password2) throws MiException{
		System.out.println("validar: " + id + nombreUsuario + " " + rol + " " + password + " " + password2 );
	validar(nombreUsuario, rol, password, password2);

	Periodista periodista = new Periodista();
	Usuario usuario = new Usuario();
		Optional<Usuario> respuesta = usuarioRepositorio.findById(id);
		if (respuesta.isPresent()) {
			usuario = respuesta.get();
		}
		usuario.setNombreUsuario(nombreUsuario);
		if(rol.equals(rol.USER)){
			usuario.setRol(Rol.USER);
		}
		if (rol.equals(rol.ADMIN)) {
			usuario.setRol(Rol.ADMIN);
		}
		if (rol.equals(rol.PERIODISTA)) {
			usuario.setRol(Rol.PERIODISTA);
		}
		if (archivoNew != null) {
			System.out.println("new " + archivoNew);
			String idImagen = null;
			if (usuario.getImagen() != null) {
				idImagen = usuario.getImagen().getId();
			}
			Imagen imagen = imagenServicio.actualizar(archivoNew, idImagen);
			usuario.setImagen(imagen);
		} else {
			System.out.println("sin imagen nueva");
		}
		
//		usuario.setPassword(password);
		String pass = usuario.getPassword();
		if (password.equals(pass)) {
			System.out.println("sin cambio de password");
		} else {
			usuario.setPassword(new BCryptPasswordEncoder().encode(password));
		}	
	usuario.setActivo(Boolean.TRUE);

	usuarioRepositorio.save(usuario);
		System.out.println("usuario0: " + usuario.toString());
	if (usuario.getRol().equals(Rol.PERIODISTA)) {
		String idPeriodista = usuario.getId();

		periodistaServicio.registrarPeriodista(idPeriodista);		

		System.out.println("usuario1: " + usuario.toString());
		Optional<Periodista> respuesta1 = periodistaRepositorio.findById(usuario.getId());
		if (respuesta1.isPresent()) {
			periodista = respuesta1.get();
			usuario.setPeriodista(periodista);
		} else {
//			periodistaServicio.registrarPeriodista(idPeriodista);
//			usuario.setPeriodista(periodistaServicio.getOne(idPeriodista));
		}

		usuarioRepositorio.save(usuario);
		System.out.println("usuario2: " + usuario.toString());
	}

}

public List<Usuario> listarTodos() {
	List<Usuario> todos = new ArrayList();
	todos = usuarioRepositorio.findAll();
	return todos;
}

public List<Usuario> listarUsuarios(){
	List<Usuario> usuariosTodos = usuarioRepositorio.findAll();
	List<Usuario> usuarios = new ArrayList();
	for (Usuario usuario : usuariosTodos) {
		if (usuario.getRol().equals(Rol.USER)) {
			usuarios.add(usuario);
			System.out.println("usuarios: " + usuario.toString());
		}
	}
	return usuarios;	
}
public List<Usuario> listarPeriodistas(){
	List<Usuario> usuariosTodos = usuarioRepositorio.findAll();
	List<Usuario> periodistas = new ArrayList();
	for (Usuario periodista : usuariosTodos) {
		if (periodista.getRol().equals(Rol.PERIODISTA)) {
			periodistas.add(periodista);
			System.out.println("periodistas: " + periodista.toString());
		}
	}
	return periodistas;	
}

public Usuario getOne(String id){
	return usuarioRepositorio.getOne(id);
}

public void rotarRol(String id){
	
	Optional<Usuario> respuesta = usuarioRepositorio.findById(id);
	if (respuesta.isPresent()) {
			Rol rol = respuesta.get().getRol();
		Usuario usuario = respuesta.get();
		
		System.out.println("r0:" + usuario.getRol());
		if (rol.equals(Rol.USER)) {
			usuario.setRol(Rol.PERIODISTA);
			System.out.println(rol);
			System.out.println("ru" + usuario.getRol());
		} 
		if (rol.equals(Rol.PERIODISTA)) {
			usuario.setRol(Rol.ADMIN);
			System.out.println(rol);
			System.out.println("rp:" + usuario.getRol());
		}
		if(rol.equals(Rol.ADMIN)) {
			usuario.setRol(Rol.USER);
			System.out.println(rol);
			System.out.println("ra:" + usuario.getRol());
		}
		usuarioRepositorio.save(usuario);
	}
}

public void validar(String nombreUsuario, Rol rol, String password, String password2) throws MiException{
	if (nombreUsuario.isEmpty()) {
		throw new MiException("el nombre no puede ser nulo o estar vacio");
	}
	if(!rol.equals(rol.USER)){
		if (!rol.equals(rol.ADMIN)) {
			if (!rol.equals(rol.PERIODISTA)) {
				throw new MiException("el rol no puede ser nulo o estar vacio");
			}
		}
	}
	if (password.isEmpty() || password == null || password.length() <=5) {
		throw new MiException("la contraseña no puede estar vacia, y debe tener mas de 5 digitos");
	}
	if (!password.equals(password2)) {
		throw new MiException("las contraseñas ingresadas deben ser iguales");
	}
}

	@Override
	public UserDetails loadUserByUsername(String nombreUsuario) throws UsernameNotFoundException {

		Usuario usuario = usuarioRepositorio.buscarPorNombreUsuario(nombreUsuario);
		if (usuario != null) {
			List<GrantedAuthority> permisos = new ArrayList();
			GrantedAuthority p = new SimpleGrantedAuthority("ROLE_" + usuario.getRol().toString());  //ROLE_USER
			permisos.add(p);
			
			//seguridad para ROLE_ADMIN
			ServletRequestAttributes attr =  (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
			HttpSession session = attr.getRequest().getSession(true);
			session.setAttribute("usuariosession", usuario);
			
			User user = new User(usuario.getNombreUsuario(), usuario.getPassword(), permisos);
			return user;
		} else {
			return null;
		}
	}


}
