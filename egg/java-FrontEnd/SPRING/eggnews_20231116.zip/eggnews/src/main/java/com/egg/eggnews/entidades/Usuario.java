
package com.egg.eggnews.entidades;

import com.egg.eggnews.enumeraciones.Rol;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

@Entity
public  class Usuario {
	@Id
	@GeneratedValue(generator="uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	protected String id;
	protected String nombreUsuario;
	protected String password;
	@Temporal(TemporalType.DATE)
	protected Date fechaAlta;
	@Enumerated(EnumType.STRING)
	protected Rol rol;
	protected Boolean activo;
	@OneToOne
	protected Periodista periodista;
	@OneToOne
	protected Imagen imagen;

	public Usuario() {
	}

	public Usuario(String id, String nombreUsuario, String password, Date fechaAlta, Rol rol, Boolean activo) {
		this.id = id;
		this.nombreUsuario = nombreUsuario;
		this.password = password;
		this.fechaAlta = fechaAlta;
		this.rol = rol;
		this.activo = activo;
	}

	public Periodista getPeriodista() {
		return periodista;
	}

	public void setPeriodista(Periodista periodista) {
		this.periodista = periodista;
	}

	public Usuario(String id){
		this.id=id;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNombreUsuario() {
		return nombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getFechaAlta() {
		return fechaAlta;
	}

	public void setFechaAlta(Date fechaAlta) {
		this.fechaAlta = fechaAlta;
	}

	public Rol getRol() {
		return rol;
	}

	public void setRol(Rol rol) {
		this.rol = rol;
	}

	public Boolean getActivo() {
		return activo;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	public Imagen getImagen() {
		return imagen;
	}

	public void setImagen(Imagen imagen) {
		this.imagen = imagen;
	}

	@Override
	public String toString() {
		return "Usuario{" + "id=" + id + ", nombreUsuario=" + nombreUsuario + ", password=" + password + ", fechaAlta=" + fechaAlta + ", rol=" + rol + ", activo=" + activo + ", periodista=" + periodista + ", imagen=" + imagen + '}';
	}




}
