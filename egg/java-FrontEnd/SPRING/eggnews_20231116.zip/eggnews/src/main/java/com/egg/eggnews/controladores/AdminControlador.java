
package com.egg.eggnews.controladores;

import com.egg.eggnews.entidades.Noticia;
import com.egg.eggnews.entidades.Usuario;
import com.egg.eggnews.enumeraciones.Rol;
import com.egg.eggnews.excepciones.MiException;
import com.egg.eggnews.servicios.NoticiaServicio;
import com.egg.eggnews.servicios.UsuarioServicio;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/admin")
public class AdminControlador {
	@Autowired
	UsuarioServicio usuarioServicio;
	@Autowired
	NoticiaServicio noticiaServicio;

@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_PERIODISTA')")	
@GetMapping("/inicio")
public String inicio(HttpSession session, ModelMap modelo){
	Usuario logueado = (Usuario) session.getAttribute("usuariosession");
	if (logueado.getRol().equals(Rol.ADMIN)) {
		List<Noticia> noticias = noticiaServicio.listarNoticias();
		modelo.addAttribute("noticias", noticias);
	}
	if (logueado.getRol().equals(Rol.PERIODISTA)) {
	List<Noticia> noticias = noticiaServicio.listarMisNoticias(logueado.getId());
	modelo.addAttribute("noticias", noticias);
	}

	return "inicio.html";

}	
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/usuario/registrar/{var}")
	public String usuarioRegistrar(@PathVariable(required = false) Rol var, ModelMap modelo){
		modelo.addAttribute("roles", Rol.values() );
		modelo.put("var", var);
		return "usuario_registro.html";
	}
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/periodista/registrar/{var}")
	public String periodistaRegistrar(@PathVariable(required = false) Rol var, ModelMap modelo){
		modelo.addAttribute("roles", Rol.values() );
		modelo.put("var", var);
		return "usuario_registro.html";
	}	
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/usuario/registro")
	public String usuarioRegistro(MultipartFile archivo, @RequestParam String nombreUsuario, @RequestParam Rol rol, @RequestParam String password, @RequestParam String password2, ModelMap modelo){
		try {
			usuarioServicio.registrarUsuario(archivo, nombreUsuario, rol, password, password2);
			
			modelo.put("exito", "Usuario registrado correctamente");
			return "index.html";
		} catch (MiException ex) {
			modelo.addAttribute("roles", Rol.values() );
			modelo.put("error", ex.getMessage());
			modelo.put("nombre", nombreUsuario);
			modelo.put("rol", rol);
			return "usuario_registro.html";
		}
	}
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/perfil/{id}")
	public String modificar(@PathVariable String id, ModelMap modelo){
		Usuario usuario = usuarioServicio.getOne(id);
		modelo.put("usuario", usuario);
		modelo.addAttribute("roles", Rol.values() );

		return "usuario_modificar.html";
	}
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/perfil/{id}")
	public String modificar(MultipartFile archivoNew, @PathVariable String id, @RequestParam String nombreUsuario, @RequestParam Rol rol, @RequestParam String password, @RequestParam String password2, ModelMap modelo){
		
		try {
			Usuario usuario = usuarioServicio.getOne(id);
			modelo.put("usuario", usuario);
			modelo.put("archivo", usuario.getImagen());
			System.out.println("archivoNew" + archivoNew);
			System.out.println("archivo" + usuario.getImagen());
			usuarioServicio.modificarUsuario(archivoNew, id, nombreUsuario, rol, password, password2);
			modelo.put("exito", "Usuario actualizado correctamente");
			return "redirect:../admin/panelAdmin";
			
		} catch (MiException ex) {
			Usuario usuario = usuarioServicio.getOne(id);
			modelo.put("usuario", usuario);
			modelo.addAttribute("roles", Rol.values() );
			modelo.put("error", ex.getMessage());
		
			return "usuario_modificar.html";
		}
	}
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/usuario/lista")
	public String listaUsuarios(ModelMap modelo){
		List<Usuario> usuarios = usuarioServicio.listarUsuarios();
		modelo.addAttribute("usuarios", usuarios);
		return "usuario_list.html";
	}
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/periodista/lista")
	public String listaPeriodistas(ModelMap modelo){
		List<Usuario> usuarios = usuarioServicio.listarPeriodistas();
		modelo.addAttribute("usuarios", usuarios);
		return "usuario_list.html";
	}
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/todos/lista")
	public String listaTodos(ModelMap modelo){
		List<Usuario> usuarios = usuarioServicio.listarTodos();
		modelo.addAttribute("usuarios", usuarios);
		return "usuario_list.html";
	}
	
	@GetMapping("/rotarRol/{id}")
	public String rotarRol(@PathVariable String id, ModelMap modelo){
		modelo.put("usuario", usuarioServicio.getOne(id));
		usuarioServicio.rotarRol(id);
		Rol rol = usuarioServicio.getOne(id).getRol();
			if (rol.equals(rol.USER)) {
				List<Usuario> usuarios = usuarioServicio.listarUsuarios();
				modelo.addAttribute("usuarios", usuarios);
			}
			if (rol.equals(rol.PERIODISTA)) {
				List<Usuario> usuarios = usuarioServicio.listarPeriodistas();
				modelo.addAttribute("usuarios", usuarios);
			}
			if (rol.equals(rol.ADMIN)) {
				List<Usuario> usuarios = usuarioServicio.listarTodos();
				modelo.addAttribute("usuarios", usuarios);
			}
		return "usuario_list.html";
	}	

	
@PostMapping("/cambiarCreador/{id}")
public String cambiarCreador(@PathVariable String id, @RequestParam String idPeriodista, ModelMap modelo) {

	try {
		noticiaServicio.cambiarCreador(id, idPeriodista);
		List<Usuario> periodistas = usuarioServicio.listarPeriodistas();		
		modelo.addAttribute("periodistas", periodistas);
		List<Noticia> noticias = noticiaServicio.listarNoticias();
		modelo.addAttribute("noticias", noticias);
		modelo.put("exito", "creador modificado");
	} catch (Exception ex) {
		List<Usuario> periodistas = usuarioServicio.listarPeriodistas();
		modelo.addAttribute("periodistas", periodistas);
		List<Noticia> noticias = noticiaServicio.listarNoticias();
		modelo.addAttribute("noticias", noticias);
		modelo.put("error", ex.getMessage());
		return "noticia_list.html";
	}

	return "noticia_list.html";
}
	
		@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/perfil/rol/{id}")
	public String modificarRol(MultipartFile archivo, @PathVariable String id, @RequestParam String nombreUsuario, @RequestParam Rol rol, @RequestParam String password, @RequestParam String password2, ModelMap modelo){
		
		try {
			usuarioServicio.modificarUsuario(archivo, id, nombreUsuario, rol, password, password2);
			modelo.put("exito", "Usuario actualizado correctamente");
			if (rol.equals(rol.USER)) {
				List<Usuario> usuarios = usuarioServicio.listarUsuarios();
				modelo.addAttribute("usuarios", usuarios);
			}
			if (rol.equals(rol.PERIODISTA)) {
				List<Usuario> usuarios = usuarioServicio.listarPeriodistas();
				modelo.addAttribute("usuarios", usuarios);
			}
			if (rol.equals(rol.ADMIN)) {
				List<Usuario> usuarios = usuarioServicio.listarTodos();
				modelo.addAttribute("usuarios", usuarios);
			}
			return "usuario_list.html";			
		} catch (MiException ex) {
			modelo.put("error", ex.getMessage());
			modelo.put("nombre", nombreUsuario);
			modelo.put("rol", rol);
			
			return  "usuario_list.html";
		}
	}
	
@PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_PERIODISTA')")
@GetMapping("/panelAdmin")
public String panel(ModelMap modelo){
	List<Noticia> noticias = noticiaServicio.listarNoticias();
	modelo.addAttribute("noticias", noticias);
	return "panelAdmin.html";
}

@PreAuthorize("hasAnyRole('ROLE_USER','ROLE_ADMIN', 'ROLE_PERIODISTA')")
@GetMapping("/panelAdmin/lista")
public String panelAdminListaNoticias(ModelMap modelo, HttpSession session){
	List<Usuario> periodistas = usuarioServicio.listarPeriodistas();
	modelo.addAttribute("periodistas", periodistas);
	List<Noticia> noticias = noticiaServicio.listarNoticias();
	modelo.addAttribute("noticias", noticias);
	return "noticia_list.html";
}

@PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_PERIODISTA')")
@GetMapping("/panelAdmin/miLista")
public String panelAdminMisNoticias(ModelMap modelo, HttpSession session){
	Usuario logueado = (Usuario) session.getAttribute("usuariosession");

	System.out.println("idss " + session.getId());
//	System.out.println("id " + logueado.getId());
	List<Usuario> periodistas = usuarioServicio.listarPeriodistas();
	modelo.addAttribute("periodistas", periodistas);
	List<Noticia> noticias = noticiaServicio.listarMisNoticias(logueado.getId());
	modelo.addAttribute("noticias", noticias);
	return "noticia_list.html";
}

@PreAuthorize("hasRole('ROLE_ADMIN')")
@GetMapping("panelAdmin/eliminar")
public String panelAdminBaja(ModelMap modelo){
	List<Noticia> noticias = noticiaServicio.listarNoticias();
	modelo.addAttribute("noticias", noticias);
	return "panelAdminEliminar.html";
}

@GetMapping("/noticia/eliminar/{id}")
public String baja(@PathVariable String id, ModelMap modelo){

	try {
		noticiaServicio.eliminarNoticia(id);
		List<Noticia> noticias = noticiaServicio.listarNoticias();
		modelo.addAttribute("noticias", noticias);
		modelo.put("exito", "La noticia fue eliminada correctamente");
		return "panelAdminBaja.html";
	} catch (MiException ex) {
		modelo.put("error", ex.getMessage());
		return "panelAdminEliminar.html";
	}
	
}
	
}
