
package com.egg.eggnews.servicios;

import com.egg.eggnews.entidades.Noticia;
import com.egg.eggnews.entidades.Periodista;
import com.egg.eggnews.entidades.Usuario;
import com.egg.eggnews.enumeraciones.Rol;
import com.egg.eggnews.repositorios.NoticiaRepositorio;
import com.egg.eggnews.repositorios.PeriodistaRepositorio;
import com.egg.eggnews.repositorios.UsuarioRepositorio;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PeriodistaServicio {
	@Autowired
	private PeriodistaRepositorio periodistaRepositorio;
	@Autowired
	private NoticiaRepositorio noticiaRepositorio;
	@Autowired
	private UsuarioRepositorio usuarioRepositorio;
	
	
	public void registrarPeriodista(String idUsuario){
		Optional<Periodista> respuesta = periodistaRepositorio.findById(idUsuario);
		if (!respuesta.isPresent()) {
			Periodista periodista = new Periodista();
			ArrayList<Noticia> misNoticias = new ArrayList();
			periodista.setId(idUsuario);
			periodista.setMisNoticias(misNoticias);
			periodista.setSueldoMensual(0);

			periodistaRepositorio.save(periodista);
			System.out.println("period:" + periodista.toString());
		} else{
			System.out.println("Periodista ya existe en la base de datos");
		}
		

		//return periodista;
	}
private void bajaPeriodista(String id){
	Optional<Usuario> respuesta = usuarioRepositorio.findById(id);
		if (respuesta.isPresent()) {
			Usuario usuario = respuesta.get();
			if (usuario.getRol().toString().equals("PERIODISTA")) {
				usuario.setRol(Rol.USER);
			}
		}
}


private void sueldoMensualPeriodista(String id, Integer sueldoMensual){
	Optional<Usuario> respuesta = usuarioRepositorio.findById(id);
	if (respuesta.isPresent()) {
		Usuario usuario = respuesta.get();
		
		Periodista periodista = new Periodista();
		periodista.setSueldoMensual(sueldoMensual);
		periodistaRepositorio.save(periodista);    //?????
		usuarioRepositorio.save(usuario);			//?????
	}
	
}

public List<Noticia> listaNoticias(Periodista creador){
	List<Noticia> noticias = noticiaRepositorio.findAll();
	ArrayList<Noticia> misNoticias = (ArrayList<Noticia>) noticias; //filtrar por creador !
	return misNoticias;
}

public Periodista getOne(String id){
	return periodistaRepositorio.getOne(id);
}

}
