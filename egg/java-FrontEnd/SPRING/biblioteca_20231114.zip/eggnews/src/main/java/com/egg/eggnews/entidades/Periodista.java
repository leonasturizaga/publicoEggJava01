
package com.egg.eggnews.entidades;

import com.egg.eggnews.enumeraciones.Rol;
import java.util.ArrayList;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

@Entity
public class Periodista {

	@Id
	private String id;
	private ArrayList<Noticia> misNoticias;
	private Integer sueldoMensual;
	
	public Periodista() {
	}

//	public Periodista(ArrayList<Noticia> misNoticias, Integer sueldoMensual, String id, String nombreUsuario, String password, Date fechaAlta, Rol rol, Boolean activo) {
//		super(id, nombreUsuario, password, fechaAlta, rol, activo);
//		this.misNoticias = misNoticias;
//		this.sueldoMensual = sueldoMensual;
//	}
//
//		public Periodista(Integer sueldoMensual, String id) {
//		super(id);
//		this.sueldoMensual = sueldoMensual;
//	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public ArrayList<Noticia> getMisNoticias() {
		return misNoticias;
	}

	public void setMisNoticias(ArrayList<Noticia> misNoticias) {
		this.misNoticias = misNoticias;
	}

	public Integer getSueldoMensual() {
		return sueldoMensual;
	}

	public void setSueldoMensual(Integer sueldoMensual) {
		this.sueldoMensual = sueldoMensual;
	}

	@Override
	public String toString() {
		return "Periodista{" + "id=" + id + ", misNoticias=" + misNoticias + ", sueldoMensual=" + sueldoMensual + '}';
	}


	

}
