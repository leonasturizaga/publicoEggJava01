
package com.egg.eggnews.controladores;

import com.egg.eggnews.entidades.Noticia;
import com.egg.eggnews.entidades.Usuario;
import com.egg.eggnews.enumeraciones.Rol;
import com.egg.eggnews.excepciones.MiException;
import com.egg.eggnews.servicios.NoticiaServicio;
import com.egg.eggnews.servicios.UsuarioServicio;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/admin")
public class AdminControlador {
	@Autowired
	UsuarioServicio usuarioServicio;
	@Autowired
	NoticiaServicio noticiaServicio;

@PreAuthorize("hasAnyRole('ROLE_USER', 'ROLE_PERIODISTA', 'ROLE_ADMIN')")	
@GetMapping("/inicio")
public String inicio(HttpSession session, ModelMap modelo){
	Usuario logueado = (Usuario) session.getAttribute("usuariosession");
	List<Noticia> noticias = noticiaServicio.listarNoticias();
	modelo.addAttribute("noticias", noticias);
	return "inicio.html";
}	
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/usuario/registrar")
	public String usuarioRegistrar(){
		return "usuario_registro.html";
	}
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/usuario/registro")
	public String usuarioRegistro(@RequestParam String nombreUsuario, @RequestParam Rol rol, @RequestParam String password, @RequestParam String password2, ModelMap modelo){
		try {
			usuarioServicio.registrarUsuario(nombreUsuario, rol, password, password2);
			modelo.put("exito", "Usuario registrado correctamente");
			return "index.html";
		} catch (MiException ex) {
			modelo.put("error", ex.getMessage());
			modelo.put("nombre", nombreUsuario);
			modelo.put("rol", rol);
			return "usuario_registro.html";
		}
	}
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/perfil/{id}")
	public String modificar(@PathVariable String id, ModelMap modelo){
		modelo.put("usuario", usuarioServicio.getOne(id));
		return "usuario_modificar.html";
	}
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/perfil/{id}")
	public String modificar(@PathVariable String id, @RequestParam String nombreUsuario, @RequestParam Rol rol, @RequestParam String password, @RequestParam String password2, ModelMap modelo){
		
		try {
			usuarioServicio.modificarUsuario(id, nombreUsuario, rol, password, password2);
			modelo.put("exito", "Usuario actualizado correctamente");
			return "inicio.html";
			
		} catch (MiException ex) {
			modelo.put("error", ex.getMessage());
			modelo.put("nombre", nombreUsuario);
			modelo.put("rol", rol);
			
			return "usuario_modificar.html";
		}
	}
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/usuario/lista")
	public String listaUsuarios(ModelMap modelo){
		List<Usuario> usuarios = usuarioServicio.listarUsuarios();
		modelo.addAttribute("usuarios", usuarios);
		return "usuario_list.html";
	}
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/periodista/lista")
	public String listaPeriodistas(ModelMap modelo){
		List<Usuario> usuarios = usuarioServicio.listarPeriodistas();
		modelo.addAttribute("usuarios", usuarios);
		return "usuario_list.html";
	}
@PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_PERIODISTA')")
@GetMapping("/panelAdmin")
public String panel(ModelMap modelo){
	List<Noticia> noticias = noticiaServicio.listarNoticias();
	modelo.addAttribute("noticias", noticias);
	return "panelAdmin.html";
}

@PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_PERIODISTA')")
@GetMapping("/panelAdmin/lista")
public String panelAdmin(ModelMap modelo, HttpSession session){
	List<Usuario> usuarios = usuarioServicio.listarPeriodistas();
	modelo.addAttribute("usuarios", usuarios);
	List<Noticia> noticias = noticiaServicio.listarNoticias();
	modelo.addAttribute("noticias", noticias);
	return "noticia_list.html";
}

@PreAuthorize("hasRole('ROLE_ADMIN')")
@GetMapping("panelAdmin/eliminar")
public String panelAdminBaja(ModelMap modelo){
	List<Noticia> noticias = noticiaServicio.listarNoticias();
	modelo.addAttribute("noticias", noticias);
	return "panelAdminEliminar.html";
}

@GetMapping("/noticia/eliminar/{id}")
public String baja(@PathVariable String id, ModelMap modelo){

	try {
		noticiaServicio.eliminarNoticia(id);
		List<Noticia> noticias = noticiaServicio.listarNoticias();
		modelo.addAttribute("noticias", noticias);
		modelo.put("exito", "La noticia fue eliminada correctamente");
		return "panelAdminBaja.html";
	} catch (MiException ex) {
		modelo.put("error", ex.getMessage());
		return "panelAdminEliminar.html";
	}
	
}
	
}
