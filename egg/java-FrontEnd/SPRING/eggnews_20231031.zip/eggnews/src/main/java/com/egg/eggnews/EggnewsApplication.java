package com.egg.eggnews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EggnewsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EggnewsApplication.class, args);
	}

}
