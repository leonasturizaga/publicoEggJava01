
package com.egg.eggnews.utilidades;

import com.egg.eggnews.entidades.Noticia;
import java.util.Comparator;


public class Comparadores {
	public static Comparator<Noticia> ordenFecha = new Comparator<Noticia>(){
		@Override
		public int compare(Noticia t, Noticia t1){
			return t.getFecha().compareTo(t1.getFecha());
		}
	};
		public static Comparator<Noticia> ordenFechaInv = new Comparator<Noticia>(){
		@Override
		public int compare(Noticia t, Noticia t1){
			return t1.getFecha().compareTo(t.getFecha());
		}
	};
}
