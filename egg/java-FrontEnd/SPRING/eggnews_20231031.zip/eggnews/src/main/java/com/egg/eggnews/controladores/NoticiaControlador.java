
package com.egg.eggnews.controladores;

import com.egg.eggnews.entidades.Noticia;
import com.egg.eggnews.excepciones.MiException;
import com.egg.eggnews.servicios.NoticiaServicio;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/")
public class NoticiaControlador {

@Autowired
private NoticiaServicio noticiaServicio;

@GetMapping("/inicio")
public String inicio(ModelMap modelo){
	List<Noticia> noticias = noticiaServicio.listarNoticias();
	modelo.addAttribute("noticias", noticias);
	return "inicio.html";
}

@GetMapping("/noticia/{id}")
public String noticia(@PathVariable String id, ModelMap modelo){
	List<Noticia> noticias = noticiaServicio.listarNoticias();
	modelo.addAttribute("noticias", noticias);
	modelo.put("noticia", noticiaServicio.getOne(id));
	return "noticia.html";
}

@GetMapping("/noticia/registrar")
public String registrar(){
	return "noticia_form.html";
}

@PostMapping("/noticia/registro")
public String registro(@RequestParam String titulo, @RequestParam String cuerpo, ModelMap modelo){
	try {
		noticiaServicio.creacion(titulo, cuerpo);
		modelo.put("exito", "Noticia creada correctamente");
			return "noticia_form.html";
	} catch (MiException ex) {
		Logger.getLogger(NoticiaControlador.class.getName()).log(Level.SEVERE, null, ex);
		modelo.put("error", ex.getMessage());
		return "noticia_form.html";
	}
}

@GetMapping("/noticia/modificar/{id}")
public String modificar(@PathVariable String id, ModelMap modelo){
	modelo.put("noticia", noticiaServicio.getOne(id));
	return "noticia_modificar.html";
}

@PostMapping("/noticia/modificar/{id}")
public String modificar(@PathVariable String id, @RequestParam String titulo, @RequestParam String cuerpo, ModelMap modelo){
	try {
		noticiaServicio.modificacion(id, titulo, cuerpo);
		modelo.put("exito", "Noticia modificada correctamente");
			return "redirect:../../inicio";
	} catch (MiException ex) {
		Logger.getLogger(NoticiaControlador.class.getName()).log(Level.SEVERE, null, ex);
		modelo.put("error", ex.getMessage());
		return "noticia_modificar.html";
	}
}

@GetMapping("/panelAdmin")
public String panel(ModelMap modelo){
	List<Noticia> noticias = noticiaServicio.listarNoticias();
	modelo.addAttribute("noticias", noticias);
	return "panelAdmin.html";
}

@GetMapping("/panelAdmin/lista")
public String panelAdmin(ModelMap modelo){
	List<Noticia> noticias = noticiaServicio.listarNoticias();
	modelo.addAttribute("noticias", noticias);
	return "panelAdminLista.html";
}

}
