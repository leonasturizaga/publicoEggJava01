
package com.egg.eggnews.servicios;

import com.egg.eggnews.entidades.Noticia;
import com.egg.eggnews.entidades.Periodista;
import com.egg.eggnews.entidades.Usuario;
import com.egg.eggnews.excepciones.MiException;
import com.egg.eggnews.repositorios.NoticiaRepositorio;
import com.egg.eggnews.repositorios.PeriodistaRepositorio;
import com.egg.eggnews.repositorios.UsuarioRepositorio;
import static com.egg.eggnews.utilidades.Comparadores.ordenFecha;
import static com.egg.eggnews.utilidades.Comparadores.ordenFechaInv;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NoticiaServicio {
	@Autowired
	private NoticiaRepositorio noticiaRepositorio;
	@Autowired
	private PeriodistaRepositorio periodistaRepositorio;
	@Autowired
	private UsuarioRepositorio usuarioRepositorio;
	
public void consulta(){

}

@Transactional()
public void creacion(String titulo, String cuerpo, String id) throws MiException{
	validar(titulo, cuerpo);
	
	Noticia noticia = new Noticia();
	noticia.setTitulo(titulo);
	noticia.setCuerpo(cuerpo);
	Date fecha = new Date();
	noticia.setFecha(fecha);
	noticia.setActivo(Boolean.TRUE);

	Optional<Periodista> respuesta = periodistaRepositorio.findById(id);
	if (respuesta.isPresent()) {
		noticia.setCreador(respuesta.get());
	}
	noticiaRepositorio.save(noticia);
	System.out.println("notica0: " + noticia.toString());

	List<Noticia> misNoticias = listarMisNoticias(id);
	for (Noticia misNoticia : misNoticias) {
		System.out.println("misnotis: " + misNoticia.toString());
	}
}

public void modificacion(String id, String titulo, String cuerpo) throws MiException{
	validar(titulo, cuerpo);
	Optional<Noticia> respuesta = noticiaRepositorio.findById(id);
	System.out.println("resp:" + respuesta.get());

	if (respuesta.isPresent()) {
		Noticia noticia = respuesta.get();
		noticia.setTitulo(titulo);
		noticia.setCuerpo(cuerpo);
		Date fechaMod = new Date();
		noticia.setFechaMod(fechaMod);
	
	noticiaRepositorio.save(noticia);		
	}
}

public void eliminarNoticia(String id) throws MiException{
	validarBaja(id);
	Optional<Noticia> respuesta = noticiaRepositorio.findById(id);
	if (respuesta.isPresent()) {
		noticiaRepositorio.deleteById(id);
	}
}

public Noticia getOne(String id){
	return noticiaRepositorio.getOne(id);
}

public List<Noticia> listarNoticias(){
	List<Noticia> noticias = new ArrayList();
	noticias = noticiaRepositorio.findAll();
	noticias.sort(ordenFechaInv);
	return noticias;
}

public List<Noticia> listarMisNoticias(String id){
	
	List<Noticia> noticias = noticiaRepositorio.findAll();
	List<Noticia> misNoticias = new ArrayList();
	Periodista creador = new Periodista();
	Optional<Periodista> respuesta = periodistaRepositorio.findById(id);
	if (respuesta.isPresent()) {
		creador = respuesta.get();
	}
	for (Noticia noticia : noticias) {
		if (noticia.getCreador() == creador) {
			misNoticias.add(noticia);
		}
	}
// OTRA FORMA, .equals(id) no funciona, solo funciona para strings
//	for (int i = 0; i < noticias.size(); i++) {
//		if (noticias.get(i).getCreador() == creador) {
//			System.out.println("noti("+i+") "+ noticias.get(i).toString());
//			misNoticias.add(noticias.get(i));
//		} else {
//		}
//	}

	return misNoticias;	
}

public void validar(String titulo, String cuerpo) throws MiException{
	if (titulo.isEmpty() || titulo == null) {
		throw new MiException("El titulo no puede estar vacio o nulo");
	}
	if (cuerpo.isEmpty() || cuerpo == null) {
		throw new MiException("El cuerpo de la noticia no puede estar vacio o nulo");
	}
	if (titulo != null && cuerpo != null) {
		System.out.println("validado");
	}
}

public void validarBaja(String id) throws MiException {
	if (id.isEmpty() || id == null) {
		throw new MiException("El id no existe o es nulo");
	}
	Optional<Noticia> respuesta = noticiaRepositorio.findById(id);
	if (respuesta.isPresent()) {
		System.out.println("id: " + id);
	} else {
		throw new MiException("Id de noticia no encontrado");
	}
}

	private void setMisNoticias() {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}

}
