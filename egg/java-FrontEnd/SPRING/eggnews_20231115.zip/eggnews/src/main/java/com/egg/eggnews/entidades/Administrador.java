
package com.egg.eggnews.entidades;

import com.egg.eggnews.enumeraciones.Rol;
import java.util.Date;
import javax.persistence.Entity;

@Entity
public class Administrador extends Usuario{

	public Administrador() {
	}

	public Administrador(String id, String nombreUsuario, String password, Date fechaAlta, Rol rol, Boolean activo) {
		super(id, nombreUsuario, password, fechaAlta, rol, activo);
	}
	


}
