
package com.egg.eggnews.excepciones;


public class MiException extends Exception{

public MiException(String msg){
	super(msg);
}

}
