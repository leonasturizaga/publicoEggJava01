
package com.egg.eggnews.enumeraciones;


public enum Rol {
	USER,
	ADMIN,
	PERIODISTA;
}
