
package com.egg.eggnews.controladores;

import com.egg.eggnews.entidades.Noticia;
import com.egg.eggnews.entidades.Periodista;
import com.egg.eggnews.entidades.Usuario;
import com.egg.eggnews.enumeraciones.Rol;
import com.egg.eggnews.excepciones.MiException;
import com.egg.eggnews.servicios.NoticiaServicio;
import com.egg.eggnews.servicios.UsuarioServicio;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/")
public class NoticiaControlador {

@Autowired
private NoticiaServicio noticiaServicio;
@Autowired
private UsuarioServicio usuarioServicio;

	@GetMapping("/")
	public String index() {
		return "index.html";
	}

	
	@GetMapping("/login")
	public String login(@RequestParam(required=false) String error, @RequestParam(required=false) String exito,  ModelMap modelo){
		if (error != null) {
			modelo.put("error", "Usuario o contraseña invalidos !");
		}
		if (exito != null) {
			modelo.put("exito", "bienvenido a EggNews");
			return "inicio.html";
		}
	return "login.html";
	}

	@GetMapping("/registrar")
	public String registrar(){
		return "usuario_registro.html";
	}
	
	@PostMapping("/registro")
	public String registro(MultipartFile archivo, @RequestParam String nombreUsuario, @RequestParam Rol rol, @RequestParam String password, @RequestParam String password2, ModelMap modelo){
		try {
			usuarioServicio.registrarUsuario(archivo, nombreUsuario, rol, password, password2);
			modelo.put("exito", "Usuario registrado correctamente");
			return "index.html";
		} catch (MiException ex) {
			modelo.put("error", ex.getMessage());
			modelo.put("nombre", nombreUsuario);
			modelo.put("rol", rol);
			return "usuario_registro.html";
		}
	}

	@PreAuthorize("hasAnyRole('ROLE_USER', 'ROLE_PERIODISTA', 'ROLE_ADMIN')")
	@GetMapping("/perfil")
	public String perfil(ModelMap modelo, HttpSession session){
		Usuario usuario = (Usuario) session.getAttribute("usuariosession");
		modelo.put("usuario", usuario);
		return "usuario_perfil.html";
	}

	
	@PreAuthorize("hasAnyRole('ROLE_USER', 'ROLE_PERIODISTA', 'ROLE_ADMIN')")
	@PostMapping("/perfil/{id}")
	public String actualizar(MultipartFile archivo, @PathVariable String id, @RequestParam String nombreUsuario, @RequestParam Rol rol, @RequestParam String password, @RequestParam String password2, ModelMap modelo){
		
		try {
			usuarioServicio.modificarUsuario(archivo, id, nombreUsuario, rol, password, password2);
			modelo.put("exito", "Usuario actualizado correctamente");
			return "inicio.html";
			
		} catch (MiException ex) {
			modelo.put("error", ex.getMessage());
			modelo.put("nombre", nombreUsuario);
			modelo.put("rol", rol);
			
			return "usuario_perfil.html";
		}
	}	
	
@PreAuthorize("hasAnyRole('ROLE_USER', 'ROLE_PERIODISTA', 'ROLE_ADMIN')")	
@GetMapping("/inicio")
public String inicio(HttpSession session, ModelMap modelo){
	Usuario logueado = (Usuario) session.getAttribute("usuariosession");
	if (logueado.getRol().toString().equals("ADMIN")) {
		System.out.println(logueado.toString());
		return "redirect:/admin/panelAdmin";
	}
	List<Noticia> noticias = noticiaServicio.listarNoticias();
	modelo.addAttribute("noticias", noticias);
	return "inicio.html";
}

@GetMapping("/noticia/{id}")
public String noticia(@PathVariable String id, ModelMap modelo){
	List<Noticia> noticias = noticiaServicio.listarNoticias();
	modelo.addAttribute("noticias", noticias);
	modelo.put("noticia", noticiaServicio.getOne(id));
	return "noticia.html";
}

@GetMapping("/noticia/registrar")
public String noticiaRegistrar(ModelMap modelo){
	List<Usuario> usuarios = usuarioServicio.listarUsuarios();
	List<Usuario> periodistas = new ArrayList();
	for (Usuario usuario : usuarios) {
		if (usuario.getPeriodista() != null) {
			periodistas.add(usuario);
		}
	}
	modelo.addAttribute("periodistas", periodistas);

	return "noticia_form.html";
}

@PostMapping("/noticia/registro")
public String noticiaRegistro(@RequestParam String titulo, @RequestParam String cuerpo, @RequestParam String idPeriodista, ModelMap modelo){
	try {
		List<Usuario> usuarios = usuarioServicio.listarUsuarios();
		List<Usuario> periodistas = new ArrayList();
		for (Usuario usuario : usuarios) {
			if (usuario.getPeriodista() != null) {
				periodistas.add(usuario);
			}
		}
		modelo.addAttribute("periodistas", periodistas);
		noticiaServicio.creacion(titulo, cuerpo, idPeriodista);
		modelo.put("exito", "Noticia creada correctamente");
			return "noticia_form.html";
	} catch (MiException ex) {
		List<Usuario> usuarios = usuarioServicio.listarUsuarios();
		List<Usuario> periodistas = new ArrayList();
		for (Usuario usuario : usuarios) {
			if (usuario.getPeriodista() != null) {
				periodistas.add(usuario);
			}
		}
		modelo.addAttribute("periodistas", periodistas);
		modelo.put("error", ex.getMessage());
		return "noticia_form.html";
	}
}

@PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_PERIODISTA')")
@GetMapping("/noticia/modificar/{id}")
public String noticiaModificar(@PathVariable String id, ModelMap modelo){
	modelo.put("noticia", noticiaServicio.getOne(id));
	return "noticia_modificar.html";
}

@PostMapping("/noticia/modificar/{id}")
public String noticiaModificar(@PathVariable String id, @RequestParam String titulo, @RequestParam String cuerpo, ModelMap modelo){
	try {
		noticiaServicio.modificacion(id, titulo, cuerpo);
		modelo.put("exito", "Noticia modificada correctamente");
			return "redirect:../../inicio";
	} catch (MiException ex) {
		Logger.getLogger(NoticiaControlador.class.getName()).log(Level.SEVERE, null, ex);
		modelo.put("error", ex.getMessage());
		return "noticia_modificar.html";
	}
}



//para usuarios



}
