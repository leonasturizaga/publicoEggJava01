package Entidades;

import java.util.ArrayList;

public class Radar {

    private int[] objeto;

    private int[][] simulador;

    private ArrayList<Object> hostiles;

    public int distancia() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void analizar() {
    }

    public void disparar() {
    }

    public int potenciaDisparo() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void volarLejos() {
    }
}
