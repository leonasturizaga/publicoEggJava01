
package Interfaces;


public interface calculosFormas {
	public void areaCirculo(int radio);
	public void perimetroCirculo(int radio);
	public void areaRectangulo(int base, int altura);
	public void perimetroRectangulo(int base, int altura);
	
}
